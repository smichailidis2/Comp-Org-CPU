/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Desktop/HRY_302/p1/ImmedExtend.vhd";



static void work_a_0694758664_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned char t28;
    unsigned char t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned char t33;
    unsigned char t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;

LAB0:    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4606);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t9 = (t0 + 4612);
    t12 = 1;
    if (6U == 6U)
        goto LAB14;

LAB15:    t12 = 0;

LAB16:    t1 = t12;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4634);
    t5 = 1;
    if (6U == 6U)
        goto LAB27;

LAB28:    t5 = 0;

LAB29:    if (t5 == 1)
        goto LAB24;

LAB25:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t9 = (t0 + 4640);
    t12 = 1;
    if (6U == 6U)
        goto LAB33;

LAB34:    t12 = 0;

LAB35:    t1 = t12;

LAB26:    if (t1 != 0)
        goto LAB22;

LAB23:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4678);
    t1 = 1;
    if (6U == 6U)
        goto LAB48;

LAB49:    t1 = 0;

LAB50:    if (t1 != 0)
        goto LAB46;

LAB47:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4700);
    t12 = 1;
    if (6U == 6U)
        goto LAB64;

LAB65:    t12 = 0;

LAB66:    if (t12 == 1)
        goto LAB61;

LAB62:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t9 = (t0 + 4706);
    t18 = 1;
    if (6U == 6U)
        goto LAB70;

LAB71:    t18 = 0;

LAB72:    t5 = t18;

LAB63:    if (t5 == 1)
        goto LAB58;

LAB59:    t16 = (t0 + 1192U);
    t17 = *((char **)t16);
    t16 = (t0 + 4712);
    t28 = 1;
    if (6U == 6U)
        goto LAB76;

LAB77:    t28 = 0;

LAB78:    t1 = t28;

LAB60:    if (t1 != 0)
        goto LAB56;

LAB57:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 4750);
    t18 = 1;
    if (6U == 6U)
        goto LAB104;

LAB105:    t18 = 0;

LAB106:    if (t18 == 1)
        goto LAB101;

LAB102:    t9 = (t0 + 1192U);
    t10 = *((char **)t9);
    t9 = (t0 + 4756);
    t28 = 1;
    if (6U == 6U)
        goto LAB110;

LAB111:    t28 = 0;

LAB112:    t12 = t28;

LAB103:    if (t12 == 1)
        goto LAB98;

LAB99:    t16 = (t0 + 1192U);
    t17 = *((char **)t16);
    t16 = (t0 + 4762);
    t29 = 1;
    if (6U == 6U)
        goto LAB116;

LAB117:    t29 = 0;

LAB118:    t5 = t29;

LAB100:    if (t5 == 1)
        goto LAB95;

LAB96:    t22 = (t0 + 1192U);
    t23 = *((char **)t22);
    t22 = (t0 + 4768);
    t33 = 1;
    if (6U == 6U)
        goto LAB122;

LAB123:    t33 = 0;

LAB124:    t1 = t33;

LAB97:    if (t1 != 0)
        goto LAB93;

LAB94:    xsi_set_current_line(81, ng0);
    t2 = xsi_get_transient_memory(32U);
    memset(t2, 0, 32U);
    t3 = t2;
    memset(t3, (unsigned char)2, 32U);
    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 32U);
    xsi_driver_first_trans_fast_port(t4);

LAB3:    t2 = (t0 + 2824);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(50, ng0);
    t16 = (t0 + 4618);
    t18 = (16U != 16U);
    if (t18 == 1)
        goto LAB20;

LAB21:    t19 = (t0 + 2904);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t16, 16U);
    xsi_driver_first_trans_delta(t19, 0U, 16U, 0LL);
    xsi_set_current_line(51, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);
    goto LAB3;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t13 = 0;

LAB17:    if (t13 < 6U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB15;

LAB19:    t13 = (t13 + 1);
    goto LAB17;

LAB20:    xsi_size_not_matching(16U, 16U, 0);
    goto LAB21;

LAB22:    xsi_set_current_line(54, ng0);
    t16 = (t0 + 1032U);
    t17 = *((char **)t16);
    t24 = (15 - 15);
    t25 = (t24 * -1);
    t26 = (1U * t25);
    t27 = (0 + t26);
    t16 = (t17 + t27);
    t18 = *((unsigned char *)t16);
    t28 = (t18 == (unsigned char)3);
    if (t28 != 0)
        goto LAB39;

LAB41:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 4662);
    t1 = (16U != 16U);
    if (t1 == 1)
        goto LAB44;

LAB45:    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 16U);
    xsi_driver_first_trans_delta(t4, 0U, 16U, 0LL);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);

LAB40:    goto LAB3;

LAB24:    t1 = (unsigned char)1;
    goto LAB26;

LAB27:    t6 = 0;

LAB30:    if (t6 < 6U)
        goto LAB31;
    else
        goto LAB29;

LAB31:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB28;

LAB32:    t6 = (t6 + 1);
    goto LAB30;

LAB33:    t13 = 0;

LAB36:    if (t13 < 6U)
        goto LAB37;
    else
        goto LAB35;

LAB37:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB34;

LAB38:    t13 = (t13 + 1);
    goto LAB36;

LAB39:    xsi_set_current_line(55, ng0);
    t19 = (t0 + 4646);
    t29 = (16U != 16U);
    if (t29 == 1)
        goto LAB42;

LAB43:    t21 = (t0 + 2904);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t30 = (t23 + 56U);
    t31 = *((char **)t30);
    memcpy(t31, t19, 16U);
    xsi_driver_first_trans_delta(t21, 0U, 16U, 0LL);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);
    goto LAB40;

LAB42:    xsi_size_not_matching(16U, 16U, 0);
    goto LAB43;

LAB44:    xsi_size_not_matching(16U, 16U, 0);
    goto LAB45;

LAB46:    xsi_set_current_line(63, ng0);
    t9 = (t0 + 1032U);
    t10 = *((char **)t9);
    t9 = (t0 + 2904);
    t11 = (t9 + 56U);
    t14 = *((char **)t11);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t10, 16U);
    xsi_driver_first_trans_delta(t9, 0U, 16U, 0LL);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 4684);
    t1 = (16U != 16U);
    if (t1 == 1)
        goto LAB54;

LAB55:    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 16U);
    xsi_driver_first_trans_delta(t4, 16U, 16U, 0LL);
    goto LAB3;

LAB48:    t6 = 0;

LAB51:    if (t6 < 6U)
        goto LAB52;
    else
        goto LAB50;

LAB52:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB49;

LAB53:    t6 = (t6 + 1);
    goto LAB51;

LAB54:    xsi_size_not_matching(16U, 16U, 0);
    goto LAB55;

LAB56:    xsi_set_current_line(67, ng0);
    t22 = (t0 + 1032U);
    t23 = *((char **)t22);
    t24 = (15 - 15);
    t26 = (t24 * -1);
    t27 = (1U * t26);
    t32 = (0 + t27);
    t22 = (t23 + t32);
    t29 = *((unsigned char *)t22);
    t33 = (t29 == (unsigned char)3);
    if (t33 != 0)
        goto LAB82;

LAB84:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 4734);
    t1 = (14U != 14U);
    if (t1 == 1)
        goto LAB89;

LAB90:    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 14U);
    xsi_driver_first_trans_delta(t4, 0U, 14U, 0LL);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 14U, 16U, 0LL);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 4748);
    t1 = (2U != 2U);
    if (t1 == 1)
        goto LAB91;

LAB92:    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 2U);
    xsi_driver_first_trans_delta(t4, 30U, 2U, 0LL);

LAB83:    goto LAB3;

LAB58:    t1 = (unsigned char)1;
    goto LAB60;

LAB61:    t5 = (unsigned char)1;
    goto LAB63;

LAB64:    t6 = 0;

LAB67:    if (t6 < 6U)
        goto LAB68;
    else
        goto LAB66;

LAB68:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB65;

LAB69:    t6 = (t6 + 1);
    goto LAB67;

LAB70:    t13 = 0;

LAB73:    if (t13 < 6U)
        goto LAB74;
    else
        goto LAB72;

LAB74:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB71;

LAB75:    t13 = (t13 + 1);
    goto LAB73;

LAB76:    t25 = 0;

LAB79:    if (t25 < 6U)
        goto LAB80;
    else
        goto LAB78;

LAB80:    t20 = (t17 + t25);
    t21 = (t16 + t25);
    if (*((unsigned char *)t20) != *((unsigned char *)t21))
        goto LAB77;

LAB81:    t25 = (t25 + 1);
    goto LAB79;

LAB82:    xsi_set_current_line(68, ng0);
    t30 = (t0 + 4718);
    t34 = (14U != 14U);
    if (t34 == 1)
        goto LAB85;

LAB86:    t35 = (t0 + 2904);
    t36 = (t35 + 56U);
    t37 = *((char **)t36);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    memcpy(t39, t30, 14U);
    xsi_driver_first_trans_delta(t35, 0U, 14U, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 14U, 16U, 0LL);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 4732);
    t1 = (2U != 2U);
    if (t1 == 1)
        goto LAB87;

LAB88:    t4 = (t0 + 2904);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 2U);
    xsi_driver_first_trans_delta(t4, 30U, 2U, 0LL);
    goto LAB83;

LAB85:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB86;

LAB87:    xsi_size_not_matching(2U, 2U, 0);
    goto LAB88;

LAB89:    xsi_size_not_matching(14U, 14U, 0);
    goto LAB90;

LAB91:    xsi_size_not_matching(2U, 2U, 0);
    goto LAB92;

LAB93:    xsi_set_current_line(78, ng0);
    t36 = xsi_get_transient_memory(16U);
    memset(t36, 0, 16U);
    t37 = t36;
    t38 = (t0 + 1032U);
    t39 = *((char **)t38);
    t24 = (15 - 15);
    t27 = (t24 * -1);
    t32 = (1U * t27);
    t40 = (0 + t32);
    t38 = (t39 + t40);
    t34 = *((unsigned char *)t38);
    memset(t37, t34, 16U);
    t41 = (t0 + 2904);
    t42 = (t41 + 56U);
    t43 = *((char **)t42);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    memcpy(t45, t36, 16U);
    xsi_driver_first_trans_delta(t41, 0U, 16U, 0LL);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 2904);
    t4 = (t2 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);
    goto LAB3;

LAB95:    t1 = (unsigned char)1;
    goto LAB97;

LAB98:    t5 = (unsigned char)1;
    goto LAB100;

LAB101:    t12 = (unsigned char)1;
    goto LAB103;

LAB104:    t6 = 0;

LAB107:    if (t6 < 6U)
        goto LAB108;
    else
        goto LAB106;

LAB108:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB105;

LAB109:    t6 = (t6 + 1);
    goto LAB107;

LAB110:    t13 = 0;

LAB113:    if (t13 < 6U)
        goto LAB114;
    else
        goto LAB112;

LAB114:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB111;

LAB115:    t13 = (t13 + 1);
    goto LAB113;

LAB116:    t25 = 0;

LAB119:    if (t25 < 6U)
        goto LAB120;
    else
        goto LAB118;

LAB120:    t20 = (t17 + t25);
    t21 = (t16 + t25);
    if (*((unsigned char *)t20) != *((unsigned char *)t21))
        goto LAB117;

LAB121:    t25 = (t25 + 1);
    goto LAB119;

LAB122:    t26 = 0;

LAB125:    if (t26 < 6U)
        goto LAB126;
    else
        goto LAB124;

LAB126:    t31 = (t23 + t26);
    t35 = (t22 + t26);
    if (*((unsigned char *)t31) != *((unsigned char *)t35))
        goto LAB123;

LAB127:    t26 = (t26 + 1);
    goto LAB125;

}


extern void work_a_0694758664_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0694758664_3212880686_p_0};
	xsi_register_didat("work_a_0694758664_3212880686", "isim/ComputeUnit_test_isim_beh.exe.sim/work/a_0694758664_3212880686.didat");
	xsi_register_executes(pe);
}

/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Desktop/HRY_302/p1/ALUentity.vhd";
extern char *IEEE_P_0774719531;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_0774719531_sub_1306448836232530671_2162500114(char *, char *, char *, char *, char *);
char *ieee_p_0774719531_sub_1496620905533649268_2162500114(char *, char *, char *, char *, char *, char *);
char *ieee_p_0774719531_sub_2255506239096166994_2162500114(char *, char *, char *, char *, int );
char *ieee_p_2592010699_sub_16439767405979520975_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_16439989832805790689_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_207919886985903570_503743352(char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_3488768497506413324_503743352(char *, unsigned char , unsigned char );


static void work_a_1847901984_3212880686_p_0(char *t0)
{
    char t32[16];
    char t47[16];
    char t48[16];
    char t59[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    char *t26;
    int t28;
    char *t29;
    char *t30;
    int t31;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned char t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned char t54;
    unsigned char t55;
    unsigned char t56;
    unsigned char t57;
    unsigned char t58;
    unsigned char t60;

LAB0:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 8775);
    t4 = xsi_mem_cmp(t1, t2, 4U);
    if (t4 == 1)
        goto LAB3;

LAB14:    t5 = (t0 + 8779);
    t7 = xsi_mem_cmp(t5, t2, 4U);
    if (t7 == 1)
        goto LAB4;

LAB15:    t8 = (t0 + 8783);
    t10 = xsi_mem_cmp(t8, t2, 4U);
    if (t10 == 1)
        goto LAB5;

LAB16:    t11 = (t0 + 8787);
    t13 = xsi_mem_cmp(t11, t2, 4U);
    if (t13 == 1)
        goto LAB6;

LAB17:    t14 = (t0 + 8791);
    t16 = xsi_mem_cmp(t14, t2, 4U);
    if (t16 == 1)
        goto LAB7;

LAB18:    t17 = (t0 + 8795);
    t19 = xsi_mem_cmp(t17, t2, 4U);
    if (t19 == 1)
        goto LAB8;

LAB19:    t20 = (t0 + 8799);
    t22 = xsi_mem_cmp(t20, t2, 4U);
    if (t22 == 1)
        goto LAB9;

LAB20:    t23 = (t0 + 8803);
    t25 = xsi_mem_cmp(t23, t2, 4U);
    if (t25 == 1)
        goto LAB10;

LAB21:    t26 = (t0 + 8807);
    t28 = xsi_mem_cmp(t26, t2, 4U);
    if (t28 == 1)
        goto LAB11;

LAB22:    t29 = (t0 + 8811);
    t31 = xsi_mem_cmp(t29, t2, 4U);
    if (t31 == 1)
        goto LAB12;

LAB23:
LAB13:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 8815);
    t3 = (t0 + 5768);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);

LAB2:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 8568U);
    t3 = (t0 + 8847);
    t6 = (t32 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 0;
    t8 = (t6 + 4U);
    *((int *)t8) = 3;
    t8 = (t6 + 8U);
    *((int *)t8) = 1;
    t4 = (3 - 0);
    t39 = (t4 * 1);
    t39 = (t39 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t39;
    t56 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t2, t1, t3, t32);
    if (t56 == 1)
        goto LAB54;

LAB55:    t8 = (t0 + 1352U);
    t9 = *((char **)t8);
    t8 = (t0 + 8568U);
    t11 = (t0 + 8851);
    t14 = (t47 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 0;
    t15 = (t14 + 4U);
    *((int *)t15) = 3;
    t15 = (t14 + 8U);
    *((int *)t15) = 1;
    t7 = (3 - 0);
    t39 = (t7 * 1);
    t39 = (t39 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t39;
    t57 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t9, t8, t11, t47);
    t55 = t57;

LAB56:    if (t55 == 1)
        goto LAB51;

LAB52:    t15 = (t0 + 1352U);
    t17 = *((char **)t15);
    t15 = (t0 + 8568U);
    t18 = (t0 + 8855);
    t21 = (t48 + 0U);
    t23 = (t21 + 0U);
    *((int *)t23) = 0;
    t23 = (t21 + 4U);
    *((int *)t23) = 3;
    t23 = (t21 + 8U);
    *((int *)t23) = 1;
    t10 = (3 - 0);
    t39 = (t10 * 1);
    t39 = (t39 + 1);
    t23 = (t21 + 12U);
    *((unsigned int *)t23) = t39;
    t58 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t17, t15, t18, t48);
    t54 = t58;

LAB53:    if (t54 == 1)
        goto LAB48;

LAB49:    t23 = (t0 + 1352U);
    t24 = *((char **)t23);
    t23 = (t0 + 8568U);
    t26 = (t0 + 8859);
    t29 = (t59 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = 0;
    t30 = (t29 + 4U);
    *((int *)t30) = 3;
    t30 = (t29 + 8U);
    *((int *)t30) = 1;
    t13 = (3 - 0);
    t39 = (t13 * 1);
    t39 = (t39 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t39;
    t60 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t24, t23, t26, t59);
    t41 = t60;

LAB50:    if (t41 != 0)
        goto LAB45;

LAB47:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 5832);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB46:    t1 = (t0 + 5592);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(59, ng0);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t33 = (t0 + 8536U);
    t35 = (t0 + 1192U);
    t36 = *((char **)t35);
    t35 = (t0 + 8552U);
    t37 = ieee_p_0774719531_sub_1496620905533649268_2162500114(IEEE_P_0774719531, t32, t34, t33, t36, t35);
    t38 = (t32 + 12U);
    t39 = *((unsigned int *)t38);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB25;

LAB26:    t42 = (t0 + 5768);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    memcpy(t46, t37, 32U);
    xsi_driver_first_trans_fast(t42);
    goto LAB2;

LAB4:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8536U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8552U);
    t6 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t48, t5, t3);
    t8 = ieee_p_0774719531_sub_1496620905533649268_2162500114(IEEE_P_0774719531, t47, t2, t1, t6, t48);
    t9 = ieee_p_0774719531_sub_2255506239096166994_2162500114(IEEE_P_0774719531, t32, t8, t47, 1);
    t11 = (t32 + 12U);
    t39 = *((unsigned int *)t11);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB27;

LAB28:    t12 = (t0 + 5768);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    t17 = (t15 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t9, 32U);
    xsi_driver_first_trans_fast(t12);
    goto LAB2;

LAB5:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8536U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8552U);
    t6 = ieee_p_2592010699_sub_16439989832805790689_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t39 = *((unsigned int *)t8);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB29;

LAB30:    t9 = (t0 + 5768);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t9);
    goto LAB2;

LAB6:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8536U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8552U);
    t6 = ieee_p_2592010699_sub_16439767405979520975_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t39 = *((unsigned int *)t8);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB31;

LAB32:    t9 = (t0 + 5768);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    t14 = (t12 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t9);
    goto LAB2;

LAB7:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8536U);
    t3 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t32, t2, t1);
    t5 = (t32 + 12U);
    t39 = *((unsigned int *)t5);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB33;

LAB34:    t6 = (t0 + 5768);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t6);
    goto LAB2;

LAB8:    xsi_set_current_line(69, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t39 = (t4 * -1);
    t40 = (1U * t39);
    t49 = (0 + t40);
    t1 = (t2 + t49);
    t41 = *((unsigned char *)t1);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t50 = (31 - 31);
    t51 = (t50 * 1U);
    t52 = (0 + t51);
    t3 = (t5 + t52);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t47 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t53 = (t7 * -1);
    t53 = (t53 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t53;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)99, t41, (char)97, t3, t47, (char)101);
    t53 = (1U + 31U);
    t54 = (32U != t53);
    if (t54 == 1)
        goto LAB35;

LAB36:    t11 = (t0 + 5768);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_delta(t11, 0U, 32U, 0LL);
    goto LAB2;

LAB9:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t39 = (31 - 31);
    t40 = (t39 * 1U);
    t49 = (0 + t40);
    t1 = (t2 + t49);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t47 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 31;
    t8 = (t6 + 4U);
    *((int *)t8) = 1;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (1 - 31);
    t50 = (t4 * -1);
    t50 = (t50 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t50;
    t3 = xsi_base_array_concat(t3, t32, t5, (char)99, (unsigned char)2, (char)97, t1, t47, (char)101);
    t50 = (1U + 31U);
    t41 = (32U != t50);
    if (t41 == 1)
        goto LAB37;

LAB38:    t8 = (t0 + 5768);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_delta(t8, 0U, 32U, 0LL);
    goto LAB2;

LAB10:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t39 = (31 - 30);
    t40 = (t39 * 1U);
    t49 = (0 + t40);
    t1 = (t2 + t49);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t47 + 0U);
    t8 = (t6 + 0U);
    *((int *)t8) = 30;
    t8 = (t6 + 4U);
    *((int *)t8) = 0;
    t8 = (t6 + 8U);
    *((int *)t8) = -1;
    t4 = (0 - 30);
    t50 = (t4 * -1);
    t50 = (t50 + 1);
    t8 = (t6 + 12U);
    *((unsigned int *)t8) = t50;
    t3 = xsi_base_array_concat(t3, t32, t5, (char)97, t1, t47, (char)99, (unsigned char)2, (char)101);
    t50 = (31U + 1U);
    t41 = (32U != t50);
    if (t41 == 1)
        goto LAB39;

LAB40:    t8 = (t0 + 5768);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t3, 32U);
    xsi_driver_first_trans_delta(t8, 0U, 32U, 0LL);
    goto LAB2;

LAB11:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t39 = (31 - 30);
    t40 = (t39 * 1U);
    t49 = (0 + t40);
    t1 = (t2 + t49);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t4 = (31 - 31);
    t50 = (t4 * -1);
    t51 = (1U * t50);
    t52 = (0 + t51);
    t3 = (t5 + t52);
    t41 = *((unsigned char *)t3);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t47 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 30;
    t11 = (t9 + 4U);
    *((int *)t11) = 0;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (0 - 30);
    t53 = (t7 * -1);
    t53 = (t53 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t53;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)97, t1, t47, (char)99, t41, (char)101);
    t53 = (31U + 1U);
    t54 = (32U != t53);
    if (t54 == 1)
        goto LAB41;

LAB42:    t11 = (t0 + 5768);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_delta(t11, 0U, 32U, 0LL);
    goto LAB2;

LAB12:    xsi_set_current_line(77, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t4 = (0 - 31);
    t39 = (t4 * -1);
    t40 = (1U * t39);
    t49 = (0 + t40);
    t1 = (t2 + t49);
    t41 = *((unsigned char *)t1);
    t3 = (t0 + 1032U);
    t5 = *((char **)t3);
    t50 = (31 - 31);
    t51 = (t50 * 1U);
    t52 = (0 + t51);
    t3 = (t5 + t52);
    t8 = ((IEEE_P_2592010699) + 4000);
    t9 = (t47 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t53 = (t7 * -1);
    t53 = (t53 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t53;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)99, t41, (char)97, t3, t47, (char)101);
    t53 = (1U + 31U);
    t54 = (32U != t53);
    if (t54 == 1)
        goto LAB43;

LAB44:    t11 = (t0 + 5768);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    t15 = (t14 + 56U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_delta(t11, 0U, 32U, 0LL);
    goto LAB2;

LAB24:;
LAB25:    xsi_size_not_matching(32U, t40, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t40, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t40, 0);
    goto LAB30;

LAB31:    xsi_size_not_matching(32U, t40, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(32U, t40, 0);
    goto LAB34;

LAB35:    xsi_size_not_matching(32U, t53, 0);
    goto LAB36;

LAB37:    xsi_size_not_matching(32U, t50, 0);
    goto LAB38;

LAB39:    xsi_size_not_matching(32U, t50, 0);
    goto LAB40;

LAB41:    xsi_size_not_matching(32U, t53, 0);
    goto LAB42;

LAB43:    xsi_size_not_matching(32U, t53, 0);
    goto LAB44;

LAB45:    xsi_set_current_line(84, ng0);
    t30 = (t0 + 5832);
    t33 = (t30 + 56U);
    t34 = *((char **)t33);
    t35 = (t34 + 56U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = (unsigned char)3;
    xsi_driver_first_trans_fast(t30);
    goto LAB46;

LAB48:    t41 = (unsigned char)1;
    goto LAB50;

LAB51:    t54 = (unsigned char)1;
    goto LAB53;

LAB54:    t55 = (unsigned char)1;
    goto LAB56;

}

static void work_a_1847901984_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(91, ng0);

LAB3:    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t1 = (t0 + 5896);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 5608);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1847901984_3212880686_p_2(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(94, ng0);
    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t1 = (t0 + 8600U);
    t3 = (t0 + 8863);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 31;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (31 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:
LAB5:    t15 = (t0 + 5960);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t15);

LAB2:    t20 = (t0 + 5624);
    *((int *)t20) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 5960);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_1847901984_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(97, ng0);

LAB3:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 1192U);
    t9 = *((char **)t8);
    t10 = (31 - 31);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_3488768497506413324_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 6024);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_fast(t16);

LAB2:    t21 = (t0 + 5640);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1847901984_3212880686_p_4(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    char *t15;
    char *t16;
    int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned char t21;
    unsigned char t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;

LAB0:    xsi_set_current_line(102, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)2);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t28 = (t0 + 6088);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    *((unsigned char *)t32) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t28);

LAB2:    t33 = (t0 + 5656);
    *((int *)t33) = 1;

LAB1:    return;
LAB3:    t2 = (t0 + 1032U);
    t9 = *((char **)t2);
    t10 = (31 - 31);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t2 = (t9 + t13);
    t14 = *((unsigned char *)t2);
    t15 = (t0 + 2152U);
    t16 = *((char **)t15);
    t17 = (31 - 31);
    t18 = (t17 * -1);
    t19 = (1U * t18);
    t20 = (0 + t19);
    t15 = (t16 + t20);
    t21 = *((unsigned char *)t15);
    t22 = ieee_p_2592010699_sub_3488768497506413324_503743352(IEEE_P_2592010699, t14, t21);
    t23 = (t0 + 6088);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    *((unsigned char *)t27) = t22;
    xsi_driver_first_trans_fast_port(t23);
    goto LAB2;

LAB5:    t2 = (t0 + 2632U);
    t6 = *((char **)t2);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    t1 = t8;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_1847901984_3212880686_p_5(char *t0)
{
    char t1[16];
    char t4[16];
    char t9[16];
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(107, ng0);

LAB3:    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t5 = ((IEEE_P_2592010699) + 4000);
    t6 = (t0 + 8536U);
    t2 = xsi_base_array_concat(t2, t4, t5, (char)99, (unsigned char)2, (char)97, t3, t6, (char)101);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t10 = ((IEEE_P_2592010699) + 4000);
    t11 = (t0 + 8552U);
    t7 = xsi_base_array_concat(t7, t9, t10, (char)99, (unsigned char)2, (char)97, t8, t11, (char)101);
    t12 = ieee_p_0774719531_sub_1496620905533649268_2162500114(IEEE_P_0774719531, t1, t2, t4, t7, t9);
    t13 = (t1 + 12U);
    t14 = *((unsigned int *)t13);
    t15 = (1U * t14);
    t16 = (33U != t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t17 = (t0 + 6152);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 33U);
    xsi_driver_first_trans_fast(t17);

LAB2:    t22 = (t0 + 5672);
    *((int *)t22) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(33U, t15, 0);
    goto LAB6;

}

static void work_a_1847901984_3212880686_p_6(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(108, ng0);
    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB3;

LAB4:
LAB5:    t16 = (t0 + 6216);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t16);

LAB2:    t21 = (t0 + 5688);
    *((int *)t21) = 1;

LAB1:    return;
LAB3:    t1 = (t0 + 2312U);
    t5 = *((char **)t1);
    t6 = (32 - 32);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t5 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 6216);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    *((unsigned char *)t15) = t10;
    xsi_driver_first_trans_fast_port(t11);
    goto LAB2;

LAB6:    goto LAB2;

}


extern void work_a_1847901984_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1847901984_3212880686_p_0,(void *)work_a_1847901984_3212880686_p_1,(void *)work_a_1847901984_3212880686_p_2,(void *)work_a_1847901984_3212880686_p_3,(void *)work_a_1847901984_3212880686_p_4,(void *)work_a_1847901984_3212880686_p_5,(void *)work_a_1847901984_3212880686_p_6};
	xsi_register_didat("work_a_1847901984_3212880686", "isim/DATAPATH_test_isim_beh.exe.sim/work/a_1847901984_3212880686.didat");
	xsi_register_executes(pe);
}
